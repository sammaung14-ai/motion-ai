MOTION AI — PWA prototype starter

Included:
- index.html: mobile prototype interface
- manifest.json: installable app metadata
- sw.js: offline cache starter

To install as an app on Android:
1. Upload these files to an HTTPS host (for example GitHub Pages).
2. Open the hosted page in Chrome.
3. Chrome menu > Add to Home screen / Install app.

Note: This prototype is NOT connected to an AI video engine yet. Generate Video currently displays a preview of the prompt/settings only. Do not put private API keys into front-end HTML/JavaScript.
